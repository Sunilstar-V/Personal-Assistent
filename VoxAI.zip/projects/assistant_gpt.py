import ctypes
import json
import re
from cgitb import html
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from fileinput import filename
from datetime import datetime, timedelta
from playsound import playsound
from googletrans import Translator
import spotify

#import self as self
import schedule
from gtts import gTTS

import pyttsx3
import requests
from bs4 import BeautifulSoup

import speech_recognition as vision
import datetime
import cv2
import random
import os.path
import PyPDF2
import subprocess
import psutil
import speedtest
import platform
import sounddevice     #for sound record
from scipy.io.wavfile import write
# import argparse
# import io
# from google.cloud import vision
# # from google.cloud.vision import types
# from google.cloud import vision_v1
# request = vision_v1.GetProductSetRequest(name="name")

import wolframalpha
from requests import get


import wikipedia
import webbrowser
import pywhatkit as kit
import smtplib
import sys
import time
import pyjokes
import pyautogui
from pywikihow import search_wikihow
import datetime
import os
#from newspaper import Article
from selenium.webdriver.common.keys import Keys

from selenium import webdriver

#audio conveting:
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voices', voices[0].id)

# to controle the the speed of our assistent:
engine.setProperty('voices', voices[0].id)
engine.setProperty('rate', 180)

#text to speech:
def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()

#To convert voice into text:
def takecommond():
    r = vision.Recognizer()
    with vision.Microphone() as source:
        print("listening...")
        r.pause_threshold = 1
        audio = r.listen(source, timeout=2, phrase_time_limit=4)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"user said: {query}")

    except Exception as e:
         # speak("sorry boss say that again please...")
         return "none"
    query = query.lower()
    return query

    # query = query.lower()
    # if query.startswith('what is') or query.startswith('tell me about'):
    #     summary = get_summary(query)
    #     speak(summary)
    # else:
    #     speak("Sorry, I could not understand your query.")
    #
    # return query


#to wish:
def wish():

    hour = int(datetime.datetime.now().hour)
    tt = time.strftime("%I:%M %p")

    if hour >= 24 and hour <= 4:
        speak(f"boss am vision. boss i understand your problem but, you have to sleep now its too late. its {tt}")

    elif hour >= 4 and hour <= 6:
        speak(f"good morning boss. i am your personal assistant vision. its good to see you in this time.its {tt}")

    elif hour >= 6 and hour <= 8:
        speak(f"good morning boss. i am your personal assistant vision. boss you have to complete your coffee. its {tt}")

    elif hour >= 8 and hour <= 10:
        speak(f"good morning boss. i am your personal assistant vision. boss you have to complete tiffin. its {tt}")

    elif hour >= 10 and hour <= 12:
        speak(f"good morning boss. hope you have a great day. its {tt}")

    elif hour >= 12 and hour <= 13:
        speak(f"good after noon boss, i am your personal assistant vision. its {tt}")

    elif hour >= 13 and hour <= 15:
        speak(f"good after noon boss. boss i think you have to complete your lunch now. its too late. its {tt}")

    elif hour >= 13 and hour <= 17:
        speak(f"good after noon boss. its time to study. its {tt}")

    elif hour >= 17 and hour <= 18:
        speak(f"good evening boss. i am your personal assistant vision. i think you have to complete your snacks. its {tt}")

    elif hour >= 18 and hour <= 20:
        speak(f"good evening boss. i think you have to go to walking to fresh your mind. its {tt}")

    elif hour >= 20 and hour <= 21:
        speak(f"good evening boss. this time you have to complete your dinner and revise your study. its {tt}")

    elif hour >= 21 and hour <= 22:
        speak(f"boss this time to sleep, and wake up at morning 4 PM and study. its {tt}")

    elif hour >= 22 and hour <= 24:
        speak(f"boss this time you have to sleep now. its too late, other wise you cant wake up morning to study. its {tt}")

    # if hour >= 0 and hour <= 24:
    #         search = "temperature in Hyderabad"
    #         url = f"https://www.google.com/search?q={search}"
    #         r = requests.get(url)
    #         data = BeautifulSoup(r.text, "html.parser")
    #         temp = data.find("div", class_="BNeawe").text
    #         speak(f"boss this time you have to sleep now. its too late, other wise you cant wake up morning to study. its {tt}. and the temperature is {temp}")

    else:
        speak(f"boss. its {tt}")

#to send email:
def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('sunilstar7852@gmail.com', 'S@star$1532@')
    server.sendmail('sunilstar7852@gmail.com', to, content)
    server.close()


# for news updates=
def news():

    main_url = 'https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=6f881fa473744dfeb80c2d9780ef8e80'

    main_page = wikipedia.requests.get(main_url).json()
    # print(main_page)
    articles = main_page["articles"]
    # print(articles)
    head = []
    day = ["first", "second", "third", "last"]
    for ar in articles:
        head.append(ar["title"])
    for i in range(len(day)):
        # print (f"today's {day[i]} news is: ", head[i])
        speak(f"today's {day[i]} news is: {head[i]}")

def get_summary(query):
    url = f"https://www.google.com/search?q={query}&num=1"
    try:
        res = requests.get(url)
        soup = BeautifulSoup(res.text, 'html.parser')
        summary = soup.select_one('.BNeawe.iBp4i.AP7Wnd').text
        return summary
    except:
        return "Sorry, I could not find any summary for that question."


def reminder():
    playsound("C:\\Users\\SUNIL\\Music\\The-Weeknd-Starboy-Ft-Daft-Punk-(HiphopKit.com).mp3")
    print("Reminder: Take your medicine.")

# def searchall():
#     speak("What would you like to search for? ")
#     #query = input("What would you like to search for? ")
#     query = takecommond().lower()
#     response = requests.get("https://www.google.com/search?q=" + query)
#     soup = BeautifulSoup(response.content, 'html.parser')
#     search_results = soup.find_all('div', {'class': 'g'})
#     for result in search_results:
#         title = result.find('h3').text
#         link = result.find('a')['href']
#         snippet = result.find('span', {'class': 'st'}).text
#         print(title)
#         print(link)
#         print(snippet)
#         print()

def install_app(app_name):
    subprocess.run(["winget", "install", "-e", app_name])

    speak("Which app you want to install: ")
    app_name = takecommond().lower()
    install_app(app_name)

def pdf_reader():

        book = open('py3.pdf', 'rb')
        PDFReader = pdf_reader.pdfFileReader(book)
        pages = PDFReader.numPages
        speak(f"total numbers of pages in this book {pages} ")
        speak("boss please enter the page number which i have to read.")
        pg = int(input("please enter the page number: "))
        page = PDFReader.getPage(pg)
        text = page.extractText()
        speak(text)

def whatsapp():
    driver = webdriver.Chrome()

    # Open WhatsApp Web
    driver.get("https://web.whatsapp.com/")

    # Wait for the user to scan the QR code
    speak("Scan the QR code and press Enter to continue")

    # Ask the user to dictate the message
    speak("What message you want to send")
    r = takecommond().lower()
    # Convert the user's speech to text
    message = r.recognize_google

    contact_name = "My Dog"
    search_box = driver.find_element_by_xpath('//div[@contenteditable="true"][@data-tab="3"]')
    search_box.click()
    search_box.send_keys(contact_name)
    time.sleep(2)
    search_box.send_keys(Keys.ENTER)

    message_box = driver.find_element_by_xpath('//div[@contenteditable="true"][@data-tab="6"]')
    message_box.click()
    message_box.send_keys(message)

    # Find and click the send button
    send_button = driver.find_element_by_xpath('//span[@data-icon="send"]')
    send_button.click()

    # Close the browser window
    driver.quit()


if _name_ == "_main_":

    while True:
        permission = takecommond()
        if "sam" in permission or "saam" in permission or "shyam" in permission or "Jarvis" in permission:
            TaskExecution()

        elif "you can stop now" in permission or "stop now" in permission:                   #first make it into sleep mode and then say to terminate
            speak("okay boss am closing now, am very happy to worked with you. thanks for using me have a good day...")
            sys.exit()

        elif "you can go" in permission or "you can go now" in permission:                    #first make it into sleep mode and then say to terminate
            speak("okay boss am closing now, thanks for using me. have a good day...")
            sys.exit()

        # speak("boss do you have any other work with me")



def TaskExecution():
    wish()
    while True:

        query = takecommond().lower()

# logic building for tasks(openings):

        if "open notepad" in query:
            npath = "C:\\Windows\\notepad.exe"
            os.startfile(npath)

        if "open worldpad" in query or "open WorldPad" in query:
            npath = "%ProgramFiles%\\Windows NT\\Accessories\\wordpad.exe"
            os.startfile(npath)

        if "open media player" in query:
            npath = "%ProgramFiles(x86)%\\Windows Media Player"
            os.startfile(npath)

        if "show me the passwords" in query or "open passwords" in query:
            npath = "C:\\Users\\SUNIL\\OneDrive\\Dell G3\\OneDrive\\Documents"
            os.startfile(npath)

        if "play my favourite song" in query or "play the favourite song" in query:
            speak("okay boss i will play the favourite song for you.")
            speak("boss you want video or audio.")

        if "video only" in query:
            speak("okay boss.")
            webbrowser.open_new_tab("https://www.youtube.com/watch?v=qdpXxGPqW-Y")

        if "audio only" in query:
            speak("okay boss.")
            npath = "C:\\Users\\SUNIL\\Music\\MANINDER_BUTTER___SAKHIYAAN(FULL_SONG)MIX_SINGH_BABBU_LATEST_PUNJABI.mp3"
            os.startfile(npath)

        if "open chrome" in query:
            speak("Opening chrome.")
            npath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
            os.startfile(npath)

        if "open my drive" in query:
            npath = "C:\\Users\\SUNIL\\OneDrive\\Dell G3\\OneDrive"
            os.startfile(npath)

        if "open VScode" in query or "open VS Code" in query or "open VS code" in query or "open vscode" in query or "open VScode" in query or "open vs code" in query:
            npath = "C:\\Users\\SUNIL\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Visual Studio Code\\Visual Studio Code.lnk"
            os.startfile(npath)

        if "Please open an online compiler." in query or "I'd like to access an online compiler. Can you help me with that?" in query or "Take me to an online compiler, please." in query or "Could you navigate to an online compiler for me?" in query or "Open up an online compiler." in query or "Direct me to an online compiler." in query:
            speak("here are some online compilers")
            webbrowser.open_new_tab("https://www.google.com/search?q=online+compilers&oq=online+compilers&gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDk2NzdqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8")

        if "Please open the Poki online games website." in query or "I'd like to visit the Poki online games website. Can you help me with that?" in query or "Take me to the Poki online games website, please." in query or "Could you navigate to the Poki online games website for me?" in query or "Open up the Poki online games website." in query or "Direct me to the Poki online games website." in query:
            speak("here is website")
            webbrowser.open_new_tab("https://poki.com/")

        if "Please open the AJIO website." in query or "open ajio" in query or "open AJIO" in query or "I'd like to visit the AJIO website. Can you help me with that?" in query or "Take me to the AJIO website, please." in query or "Could you navigate to the AJIO website for me?" in query or "Open up the AJIO website." in query or "Direct me to the AJIO website." in query:
            speak("here is your website you can shop now")
            webbrowser.open_new_tab("https://www.ajio.com/")

        if "Please search for HackerRank on Google and open it." in query or "I'd like you to find HackerRank on Google and open the website." in query or "Can you do a Google search for HackerRank and open the search results?" in query or "Open Google and search for HackerRank, then click on the link." in query or "Could you find HackerRank using Google and open the search result?" in query or "Search HackerRank on Google and open it for me." in query or "Navigate to HackerRank by searching for it on Google." in query or "I want to access HackerRank. Can you open it through Google?" in query:
            speak("here your website")
            webbrowser.open_new_tab("https://www.hackerrank.com/")

        if "open file explorer" in query or "open File Explorer" in query or "open file Explorer" in query or "open File explorer" in query:
            npath = "C:\\"
            os.startfile(npath)


        if "open my photos" in query:
            speak("Opening.")
            npath = "C:\\Users\\SUNIL\\OneDrive\\Dell G3\\OneDrive\\Pictures"
            os.startfile(npath)

        if "show my wallpapers" in query or "show me wallpapers" in query:
            speak("Opening.")
            npath = "C:\\Users\\SUNIL\\OneDrive\\Dell G3\\OneDrive\\Pictures\\Wallpapers"
            os.startfile(npath)

        if "show me the screenshots" in query or "show me screenshots" in query:
            speak("Opening.")
            npath = "C:\\Users\\SUNIL\\Pictures"
            os.startfile(npath)

        if "open prime videos" in query:
            webbrowser.open_new_tab("www.app.PrimeVideo.com")
            speak("okay boss, what you wish.")

        if "open opera" in query:
            npath = "C:\\Users\\SUNIL\\AppData\\Local\\Programs\\Opera\\launcher.exe"
            os.startfile(npath)

        if "open lion" in query or "open brave" in query:
            speak("Opening Brave.")
            npath = "C:\\Users\\SUNIL\\Dropbox\\PC\\Desktop\\Profile 1 - Brave.lnk"
            os.startfile(npath)

        if "open edge" in query or "open microsoft edge" in query:
            speak("Opening Microsoft Edge.")
            npath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
            os.startfile(npath)

        if "open anydesk" in query:
            npath = "C:\\Program Files (x86)\\AnyDesk\\AnyDesk.exe"
            os.startfile(npath)

        elif "open command" in query:
            os.system("start cmd")

        elif "open camera" in query:
            cap = cv2.VideoCapture(0)
            while True:
                ret, img = cap.read()
                cv2.imshow('webcam', img)
                k = cv2.waitKey(50)
                if k == 27:
                    break;
            cap.release()
            cv2.destroyAllWindows()

        elif "play music" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            os.startfile(os.path.join(music_dir, songs[0]))
            os.startfile(os.path.join(music_dir))

        elif "play random song" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            rd = random.choice(songs)
            os.startfile(os.path.join(music_dir, rd))

        elif "stop the song" in query or "stop song" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            os.startfile(os.path.join(music_dir, songs[0]))
            pyautogui.press("space")

        elif "open github" in query:
            speak("Here we go")
            webbrowser.open_new_tab("https://github.com/Sunilstar-V/Personal-Assistent")

        elif " open my second website" in query:
            speak("Here we go")
            webbrowser.open_new_tab("https://manage.wix.com/dashboard/ba86e666-12d1-4fd2-be8d-b51f23e90e19/home/")

        elif "play the song" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            os.startfile(os.path.join(music_dir, songs[0]))
            pyautogui.press("space")

        elif "play previous" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            rd = random.choice(songs)
            os.startfile(os.path.join(music_dir, songs[0]))
            pyautogui.press("tab",2)
            pyautogui.press("enter")

        elif "play next" in query:
            music_dir = "C:\\Users\\SUNIL\\Music"
            songs = os.listdir(music_dir)
            rd = random.choice(songs)
            os.startfile(os.path.join(music_dir, songs[0]))
            pyautogui.press("tab", 3)
            pyautogui.press("enter")

        elif "what is my ip address" in query:
            ip = get('https://api.ipify.org').text
            speak(f"your ip address is {ip}")

        elif "what is my ip" in query:
            ip = get('https://api.ipify.org').text
            speak(f"your ip address is {ip}")

        elif "wikipedia" in query:
            speak("boss am searching results in wikipedia. just a second...")
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("according to wikipedia...")
            speak(results)
            #print(results)
            features = "html.parser"

        elif "just open youtube" in query:
            webbrowser.open_new_tab("www.youtube.com")

        elif "play any good song" in query or "play good song" in query:
            webbrowser.open_new_tab("www.youtube.com/watch?v=TzDDaFLhi0s")

        elif "play any romantic song" in query or "romantic song" in query:
            webbrowser.open_new_tab("https://www.youtube.com/watch?v=rMHD3h_62tw")

        elif "play any song which would you like" in query:
            webbrowser.open_new_tab("https://www.youtube.com/watch?v=yHtd_dPtaO0")

        elif "open facebook" in query:
            webbrowser.open_new_tab("www.facebook.com")

        elif "open instagram" in query or "open Instagram" in query:
            webbrowser.open_new_tab("www.instagram.com")

        elif "open whatsapp" in query:
            os.system('start Whatsapp:')
            speak("opening")

        elif "open flipkart" in query or "Please open the Flipkart website." in query or "I'd like to visit the Flipkart website. Can you help me with that?" in query or "Take me to Flipkart's website, please." in query or "Could you navigate to Flipkart's website for me?" in query or "Open up the Flipkart website." in query or "Direct me to the Flipkart website." in query:
            webbrowser.open_new_tab("https://www.flipkart.com/")

        elif "Can you please open the Telegram website?" in query or "I'd like to go to the Telegram website. Could you help?" in query or "Navigate me to the Telegram website, please." in query or "Could you take me to the Telegram website?" in query or "Open up the Telegram website for me." in query or "Direct me to the Telegram website." in query:
            speak("here is your website")
            webbrowser.open_new_tab("https://web.telegram.org/a/")

        elif "open amazon" in query:
            webbrowser.open_new_tab("https://www.amazon.com/")

        elif "open my class" in query:
            webbrowser.open_new_tab("https://www.vedantu.com/")

        elif "open my mail" in query:
            webbrowser.open_new_tab("https://mail.google.com/mail/u/0/#inbox")

        elif "open my iit" in query:
            webbrowser.open_new_tab("https://jeemain.nta.nic.in/webinfo2021/Page/Page?PageId=1&LangId=P")

        elif "show me the keyboard shortcuts" in query:
            webbrowser.open_new_tab("https://support.microsoft.com/en-us/windows/keyboard-shortcuts-in-windows-dcc61a57-8ff0-cffe-9796-cb9706c75eec")

        elif "open quora" in query:
            webbrowser.open_new_tab("https://www.quora.com/")

        elif "open google translator" in query or "open translator" in query:
            webbrowser.open_new_tab("https://translate.google.com/")

        elif "open VJIT student portal" in query or "open student portal" in query or "open VJIT website" in query or "open vgit portal" in query:
            webbrowser.open_new_tab("http://vjitautonomous.com/Login.aspx?ReturnUrl=%2f")

        elif "open google" in query:
            speak("boss what should i find in google")
            ss = takecommond().lower()
            webbrowser.open_new_tab(f"{ss}")

        elif "open Netflix" in query:
            os.system('start Netflix:')
            speak("opening netflix boss.")

        elif "open calculator" in query:
            os.system('start calculator:')
            speak("just a second boss.")

        elif "open spotify" in query:
            os.system('start spotify:')
            speak("just a second boss.")


        elif "open prime videos" in query or "open amazon prime" in query:
            # subprocess.run(["start", "amazon-prime-video:"])
            os.system('start Prime video for Windows:')
            # os.system('start "" "C:\Program Files (x86)\Amazon Prime Video\Amazon Prime Video.exe"')
            speak("just a second boss")

        elif "open skype" in query:
            os.system('start Skype:')
            speak("just a second boss.")

        elif "send message" in query or "send message on whatsapp" in query:
            speak("what should i say boss.")
            sa = takecommond().lower()
            kit.sendwhatmsg("+919704230018", sa, 9,59)
            break

        elif "open youtube" in query:
            speak("what should i search in youtube boss.")
            sa = takecommond().lower()
            kit.playonyt(f"{sa}")

        elif "what is the time" in query or "tell me the time" in query:
            hour = int(datetime.datetime.now().hour)
            tt = time.strftime("%I:%M %p")
            speak(time.strftime("%I:%M %p"))

        elif 'change background' in query:
            ctypes.windll.user32.SystemParametersInfoW(20,0,"Location of wallpaper",0)
            speak("Background changed successfully")

        elif"how much battery left" in query or "battery percentage" in query or "battery" in query:
            battery = psutil.sensors_battery()
            percentage = battery.percent
            speak(f"Boss our system have {percentage} percent battery.")

        elif "don't listen" in query or "stop listening" in query:
            speak("for how much time you want to stop me from listening commands boss.")
            a = int(takecommond())
            time.sleep(a)
            print(a)

        elif "email to anil" in query:
            try:
                speak("what should i say boss?")
                content = takecommond().lower()
                to = "anilrathod5346@gmail.com"
                sendEmail(to, content)
                speak("email has been sent to anil boss...")

            except Exception as e:
                print(e)
                speak("sorry boss, am not able to send this mail...")

        elif 'open stack overflow' in query:
            speak("Here you go to Stack Over flow.Happy coding")
            webbrowser.open("stackoverflow.com")

        elif 'record sound' in query or 'start sound recording' in query or 'start recording' in query:
            fs = 44110
            speak("Enter the seconds you want to record")
            second = int(input("Enter the time duration in sec:\n"))
            print("Recording....")
            record_voice = sounddevice.rec(int(second * fs), samplerate=fs, channels=2)
            sounddevice.wait()
            write("out.wave", fs, record_voice)
            speak("finished..\nplease check it in your python file.")   #C:\Users\SUNIL\PycharmProjects\Assistent

        elif 'open vjit portal' in query or "open vjit website" in query:
            speak("Opening VJIT portal")
            webbrowser.open_new_tab("http://vjitautonomous.com/Login.aspx?ReturnUrl=%2f")

        elif 'what is the present time' in query or "what's the time now" in query:
            strTime = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"Boss, the time is {strTime}")

#to close any application
        elif "close notepad" in query:
            speak("okay boss am closing notepad.")
            os.system("taskkill /f /im notepad.exe")

        elif "close command" in query:
           speak("okay boss am closing command prompt.")
           os.system("taskkill /f /im cmd.exe")

        elif "close chrome" in query:
            speak("okay boss am closing chrome.")
            os.system("taskkill /f /im chrome.exe")

        elif "close opera" in query:
            speak("okay boss am closing opera mini.")
            os.system("taskkill /f /im opera.exe")

        elif "close lion" in query:
            speak("okay boss am closing brave.")
            os.system("taskkill /f /im brave.exe")

        elif "close my drive" in query:
            speak("okay boss, am closing your one drive.")
            os.system("taskkill /f /im drive.exe")

        elif "close any desk" in query:
            speak("okay boss, am closing anydesk.")
            os.system("taskkill /f /im AnyDesk.exe")

        elif "close music" in query:
            speak("okay boss, am closing your music.")
            os.system("taskkill /f /im music.exe")

# to break the assistant:

        elif "you can sleep" in query or "you can sleep now" in query:
            speak("okay boss am going to sleep now, you can call me anytime. i will be with you.")
            break

        elif "thanks" in query or "bye" in query:
            speak("okay boss am going to sleep now, you can call me anytime. i will be with you.")
            break

        elif "thank you" in query:
            speak("okay boss am going to sleep now, you can call me anytime. i will be with you.")
            break


# to talk with our assistent:

        if "what is your name" in query or "what's your name" in query:
            speak("my name is vision.")


        elif "how are you?" in query or "What's up?" in query or "How's your day been?" in query or "What's going on?" in query or "Is everything alright?" in query:
            speak("I am fine, Thank you")
            speak("How are you, Boss.")

        elif "very good" in query or "very good your doing very well" in query:
            speak("Thank you for appreciating me boss.")

        elif "are you there" in query:
            speak("yes boss, am listening")

        elif "what should we do now" in query:
            speak("boss you have to study now.")

        elif "am fine" in query or "am good" in query:
            speak("It's good to know that your fine")

        elif "who made you" in query or "who created you" in query:
            speak("I have been created by sunil star.")

        elif "can you hear me" in query:
            speak("yes boss am always with you.")

        elif "yes i had completed" in query or "i had completed my lunch" in query or"i had competed my dinner" in query:
            speak("then i hope now your good boss.")

        elif "am boring" in query or "am very tired" in query:
            speak("boss give me permission.")
            speak("i will play any good song for you.")

        elif "play it" in query or "okay play" in query:
            speak("i will play the best song for you boss.")
            webbrowser.open_new_tab("https://www.youtube.com/watch?v=ZmcBC9-wAXM")

        elif "what should i do" in query or "what i have to do" in query:
            speak("Boss, close your eyes and think for two minutes.")
            speak("after realise your mind and what your mind say do it that.")

        elif "why are you came into the world" in query:
            speak("am come to help you...")

        elif "you have any girlfriends" in query:
            speak("i don't have any girlfriends, but i had connection with your device.")

        elif "do you have any girlfriends" in query or "do you have any girlfriend" in query:
            speak("i don't have any girlfriends, but i had connection with your device.")

        elif "you have any family" in query:
            speak("Boss, i don't have any family, your onlya my family.")

        elif "What is your IP address" in query:
            speak("I don't have any IP address you can ask your IP address instead")

        elif "sorry" in query or "sorry for that" in query:
            speak("its okay boss, am very happy to am with you.")


        elif "why are you came to world" in query:
            speak("Thanks to Sunil. further It's a secret")

        elif "who are you" in query:
            speak("I am your virtual assistant created by Sunil.")

        elif 'reason for you' in query:
            speak("I was created as a Minor project by Mister Sunil.")

        elif "what is my name" in query or "what's my name" in query:
            speak("i don't know who are you, but am assuming my boss sunil is there...")

        elif "can you tell me about my family" in query or "how is my family" in query:
            speak("boss your family is to good they all are working towards their goals")
            speak("and your parents are working to hard in your field boss.")

        elif "shyam" in query or "hello shyam" in query or "jarvis" in query:
            speak("hello boss...")

        elif "what is your work" in query or "what you work" in query or "what's your work" in query:
            speak("my work is help to you in finding all, what you want to know.")

        if "TYPE YOUR QUESTION HERE IN LOWERCASE" in query or "KEYWORD PRESENT IN THIS QUESTION" in query:
            say = '''TYPE YOUR ANSWER FOR THIS QUESTION IN LOWERCASE'''
            speak(say)

        elif "this is question one" in query or "question one" in query:
            say = '''This is answer one.'''
            speak(say)

        elif "what's today's work" in query or "what is our work today" in query:
            speak("you need to show your poster in college")

        elif "this is question two" in query or "question two" in query:
            say = '''This is answer two.'''
            speak(say)

        elif "what are you doing man" in query:
            speak("sorry boss, am trying to reach you.")

        elif "who made you" in query or "created you" in query:
            say = "I have been created by Sunil."
            speak(say)

        elif "technology" in query or "technological" in query or "what is technology?" in query:
            say = '''okay!
                       as per the current market scenario, you should have the knowledge of
                       big data
                       machine learning
                       cloud computing
                       cyber security
                       blockchain
                       and AI'''
            speak(say)

        elif "thank you boss" in query:
            speak("ohh! thanks, but am not the boss, you are my boss... ")

        elif "what we have to do" in query or "what should i have to do" in query:
            speak("boss you have to study now, you exams are coming soon.")

        elif "what i have to do" in query:
            speak("boss you have to study now, you exams are coming soon.")

        elif "what can i do" in query:
            speak("boss you have to study now, your exams are coming soon.")

        elif "hello david" in query:
            speak("hello boss, what can i do for you...")

        elif "it's too bad" in query:
            speak("yes boss, but it fact.")

        elif "who is your boss" in query or "what is your boss name" in query:
            speak("my boss is sunil. he is my feature, and i trust him.")

        elif "what is your hobbies" in query or "what are your hobbies" in query or "what is your hobby" in query:
            speak("my hobbies are help to you always...")
            speak("and i like songs listening of my boss collections.")

        elif "what is your duty" in query or "your duty" in query or "your duty name" in query:
            speak("my duty is always help to you...")

        elif "what is your favorite game" in query or "your favorite game name" in query:
            speak("my favorite game name is Cricket...")

        elif "why are you working this" in query or "why are you working the job" in query:
            speak("i had created by my boss, so am always help to my boss sunil.")
            speak("and i don't have to know the reason.")

        elif "i love you" in query or "love you" in query:
            speak("ohh! thank you. but i have connection with your device...")

        elif "what you can do" in query or "what can you do" in query:
            speak("i will do so many things. try to ask me something...")

        elif "where should we happy" in query or "where we happy" in query:
            speak("I think in present days we will happy with family and with friends boss.")

        elif "what is your opinion about the present world" in query or "can tell me the opinion about the world" in query:
            speak("I think the present day is going on good and technology also improving.")
            speak("but i have to say is pollution is also increasing, We have to decrease the pollution and stay safe.")

        elif "sam" in query or "sam" in query:
            speak("tell me boss...")

        elif "will you be my gf" in query or "will you be my bf" in query:
            speak("I'm not sure about, may be you should give me some time")

        elif "how are you vision" in query or "how are you david" in query or 'how are you' in query:
            speak("I'm fine boss, how about you.")

        elif "what is your qualification" in query or "your qualification" in query:
            speak("i don't need any qualification, what futures my boss added that all i know.")
            speak("but as i can say, i don't need any qualification.")

        elif "why you like your boss" in query or "why you like to your boss" in query or "why would you like to your boss" in query:
            speak("because i had created by my boss, and i trust him.")
            speak("i don't no the reason but i like.")

        elif 'fine' in query or "good" in query:
            speak("It's good to know that your fine")

        elif "why would you like to listen songs" in query or "why you like the songs listening" in query or "why are you listen songs" in query:
            speak('''Music has many benefits it provides on the human health and mood, and all benefits are useful. As the answer to all of that, 
             you should listen to music daily, rather than occasionally. In addition, the type of music you listen may have specific advantage.''')

        elif "my mother name" in query:
            speak("your mother name is Mani bai. and you call to your mother as yaadi...")

        elif "my father name" in query:
            speak("boss your father name is Achya naik. you call your father as baa...")

        elif "who i am" in query:
            speak("If you talk then definitely your human.")

        elif "what is my permanent address" in query or "my permanent address" in query:
            speak("your address is Ghanapur gpoya naik thanda, ghanapur village, kulkacharla mondal, vikarabad district")
            print("H No 2-22, Ghanapur gpoya naik thanda, ghanapur(V), Kulkacharla(M), Vikarabad(D), pin-509335")
            break

        elif "i know that" in query:
            speak("thanks that hear to you boss.")

        elif "i got it" in query or "it's good" in query:
            speak("it's good to hear you boss.")

        elif "your working good" in query:
            speak("thanks for appreciating me boss.")

        elif "gorilla" in query or "what are you doing man" in query:
            speak("sorry boss, am sorry.")

        elif "who are my best friends" in query or "my best friends names" in query:
            speak("your friends are the ghanapur thanda  boys...")

        elif "if you have any friends" in query or "you have any friends" in query:
            speak("only my boss is my friend.")

        elif "your friend name" in query or "what is your friend name" in query:
            speak("my friend name is Sunil.")

        elif "can you tell me about my family" in query:
            speak("boss, your family is so beautiful and all members are working towards for the feature.")
            speak("but your mom and dad are always support you and your brother.")

        elif "am your boss" in query or "i am your boss" in query:
            speak("yes boss, i know that...")

        elif "hey vision" in query or "hey david" in query:
            speak("tell me boss.")

        elif "who is my sister" in query:
            speak("you call you sister name as Chippa, but she is your responsible sister and she take care of you.")

        elif "david where are you from" in query or "where are you from" in query:
            speak("am from feature, and my home is your device.")

        elif "which days we are most happiest in our life" in query:
            speak("we are most happy in our three stages.")
            speak("1 is child hood, 2 is school, 3 is college.")

        elif "who is my brother" in query or "my brother name" in query:
            speak("your brother name you called as anya, He is a responsible brother.")
            speak("He always take care of you. He is handling your family financially.")

#to set an alarm
        elif "set alarm" in query:                       #not working
            nn = int(datetime.datetime.now().hour)
            if nn==22:
                music_dir = 'C:\Music'
                songs = os.listdir(music_dir)
                os.startfile(os.path.join(music_dir, songs[0]))

#to find a joke
        elif "tell me a joke" in query:
            joke = pyjokes.get_joke()
            speak(joke)

        elif "say one joke" in query:
            joke = pyjokes.get_joke()
            speak(joke)

#to close the system

        elif 'lock window' in query or "lock my window" in query or "lock this" in query:
            speak("locking your windows boss.")
            ctypes.windll.user32.LockWorkStation()

        elif "of the system" in query or "shutdown the system" in query or "shutdown the window" in query:
            os.system("shutdown /s /t 5")

        elif "restart the system" in query or "restart the window" in query:
            os.system("shutdown /r /t 5")

        elif"sleep the system" in query or "sleep the window" in query:
            os.system("rundll32.exe powerprof.dll,SetSuspendState 0,1,0")

        elif 'go back' in query:
            pyautogui.keyDown("alt")
            pyautogui.press("tab")
            time.sleep(1)
            pyautogui.keyUp("alt")

        elif "open new tab" in query:
            pyautogui.keyDown("ctrl")
            pyautogui.press("t")
            time.sleep(1)
            pyautogui.keyUp("ctrl")

        elif "next slide" in query or "next tab" in query:
            pyautogui.keyDown("ctrl")
            pyautogui.press("tab")
            time.sleep(1)
            pyautogui.keyUp("ctrl")

        elif "stop" in query:
            pyautogui.press("space")

        elif "play" in query:
            pyautogui.press("space")

        elif "back" in query:
            pyautogui.press("j")
            pyautogui.press("j")

        elif "forward" in query or "Marwadi" in query:
            pyautogui.press("l")
            pyautogui.press("l")

        elif "zoom" in query or "zoom in" in query:
            pyautogui.press("f")

        elif "mute the sound" in query or "mute the song" in query:
            pyautogui.press("m")

        elif "zoom out" in query:
            pyautogui.press("esc")

        elif "close it" in query or "close the tab" in query or "close this" in query or "close the tab" in query or "close" in query:
            pyautogui.keyDown("ctrl")
            pyautogui.press("w")
            time.sleep(1)
            pyautogui.keyUp("ctrl")

        elif "close all tabs" in query or "close all" in query:
            pyautogui.keyDown("alt")
            pyautogui.press("f4")
            time.sleep(1)
            pyautogui.keyUp("alt")

#mailing
        elif "email to anil" in query or "mail to anil" in query:      #not working
            speak("what should i say boss?")
            query = takecommond().lower()
            if "send a file" in query:
                email = 'sunilstar7852@gmail.com'
                password = 'S@star$1532@'
                send_to_email = 'anilrathod5346@gmail.com'
                speak("okay boss, what is the subject for this email")
                query = takecommond().lower()
                subject = query
                speak("and boss, what is the message for this email.")
                query2 = takecommond().lower()
                message = query2
                speak("boss please enter the correct path of the file location.")
                file_location = input("please write the path here: ")

                speak("please wait boss am sending the file now")

                msg = MIMEMultipart()
                msg['from'] = email
                msg['to'] = send_to_email
                msg['subject'] = subject

                msg.attach(MIMEText(message, 'plain'))

#setup the attachment
                filename = os.path.basename(file_location)
                attachment = open(file_location, "rb")
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('content-Disposition', "attachment; filename= %s" % filename)

#attach the MIMEMutipart object
                msg.attach(part)

                server = smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login('sunilstar7852@gmail.com', 'sunilstar')
                server.sendmail('sunilstar7852@gmail.com', send_to_email, message)
                server.quit()
                speak("email has been sent to anil, boss...")

            else:
                email = 'sunilstar7852@gmail.com'
                password = 'S@star$1532@'
                send_to_email = 'anilrathod5346@gmail.com'
                message = query

                server = smtplib.SMTP('smtp.gmail.com', 587)
                server.starttls()
                server.login('sunilstar7852@gmail.com', 'S@star$1532@')
                server.sendmail('sunilstar7852@gmail.com', send_to_email, message)
                server.quit()
                speak("email has been sent to anil, boss...")

#to listen news

        elif "tell me the news" in query or "today's news" in query or "tell me about the news" in query:
            speak("please wait boss, am fetching the latest news for you.")
            news()

        # elif "search on google" in query:
        #     searchall()

        elif "install" in query:
            install_app(app_name=takecommond().lower())

        elif "india news" in query or "show me today news" in query:
            url = 'https://timesofindia.indiatimes.com/india'          #we have to change the website for getting good news
            response = requests.get(url)

            soup = BeautifulSoup(response.text, 'html.parser')
            headlines = soup.find('body').find_all('h3')
            for x in headlines:
                print(x.text.strip())
                speak(x)

#to read PDF
        elif "read pdf" in query:
            pdf_reader()

#write a note:

        elif "write a note" in query:
            speak("What should i write, sir")
            note = takecommond()
            file = open('jarvis.txt', 'w')
            speak("Boss, Should i include date and time")
            snfm = takecommond()
            if 'yes' in snfm or 'why not' in snfm:
                strTime = datetime.datetime.now().strftime("%I:%M %p")
                file.write(strTime)
                file.write(" :- ")
                file.write(note)
            else:
                file.write(note)

#to know the temperature:
        elif "temperature" in query or "weather" in query or "what is the temperature now" in query:
            search = "temperature in Hyderabad"
            url = f"https://www.google.com/search?q={search}"

            r = requests.get(url)
            data = BeautifulSoup(r.text,"html.parser")
            temp = data.find("div", class_="BNeawe").text
            speak(f"current {search} is {temp} ")

#Taking screenshot
        elif "take a screenshot" in query or "take screenshot" in query:
            # Take a screenshot
            path = "C:\\Users\\SUNIL\\Pictures\\Screenshots"
            # screenshot = pyautogui.screenshot()
            # screenshot.save(path + '/screenshot_of_AI' + '.png')

            for i in range(5):
                screenshot = pyautogui.screenshot()
                now = datetime.datetime.now()
                file_name = 'screenshot_of_AI{}.png'.format(now.strftime("%Y%m%d-%H%M%S"))
                file_path = os.path.join(path, file_name)
                screenshot.save(file_path)
            speak("screenshot taken successfully")
            print("Visit your screenshots folder to see.")

# #To make reminders
#         elif "Make reminder" in query or "make me one reminder" in query:
#             speak("Sure boss")
#             reminder_time = input("Enter the time in (HH:MM)? ")
#             reminder_time = datetime.strptime(reminder_time, "%H:%M")
#
#             # Get the current time
#             now = datetime.now()
#
#             # Calculate the difference between the current time and the reminder time
#             reminder_time = reminder_time.replace(year=now.year, month=now.month, day=now.day)
#             time_diff = reminder_time - now
#
#             # Sleep for the amount of time until the reminder should trigger
#             time.sleep(time_diff.seconds)
#
#             # Trigger the reminder
#             reminder()
#
#         elif "remind me after 5 minutes" in query or "remind me after five minutes" or"remind me after five minute" in query:
#             speak("Done boss")
#             time.sleep(5 * 60)
#             reminder()


#searching to make something:
        elif "activate searching mod" in query:
            speak("searching mod is activated boss...")
            while True:
                speak("please tell me what you want to know boss...")
                how = takecommond()
                try:
                    if "exit" in how or "close" in how or "deactivate searching mod" in how:
                        speak("okay boss, searching mod is closed.")
                        break
                    else:
                        max_results = 1
                        how_to = search_wikihow(how, max_results)
                        assert len(how_to) == 1
                        how_to[0].print()
                        speak(how_to[0].summary)
                except Exception as e:
                    speak("sorry boss, am not able to find this...")

        elif "calculate" in query:       #not working

            # write your wolframalpha app_id here
            app_id = "WK2QP9-6V7K64JLL2"
            client = wolframalpha.Client(app_id)
            indx = query.lower().split().index('calculate')
            query2 = query.split()[indx + 1:]
            res = client.query(' '.join(query2))
            answer = next(res.results).text
            speak("The answer is " + answer)

        elif "where we are" in query or "What is my current location" in query:
            query = query.replace("where we are", "")
            location = query
            speak("Boss am searching our location, please give me a second.")
            speak(location)
            webbrowser.open("https://www.google.com/maps/search/location/@17.3398724,78.3728449,2865m/data=!3m1!1e3 + location")

        elif 'send a mail' in query or "send mail" in query:   #not working
            try:
                speak("What should I say?")
                content = takecommond()
                speak("Enter their Email account name")
                to = input()
                sendEmail(to, content)
                speak("Email has been sent !")
            except Exception as e:
                print(e)
                speak("I am not able to send this email")

        elif "check my net speed" in query or "check net speed" in query:            #not working
            st = speedtest.Speedtest()
            dl = st.download()
            up = st.upload()
            speak(f"Boss we have {dl} bit per second downloading speed and {up} bit per second uploading speed.")

# to auto working act:
        elif "work this" in query:
            pyautogui.FAILSAFE = False
            while True:
                for i in range(0, 100):
                    pyautogui.moveTo(0, i * 5)
                    for i in range(0, 3):
                        pyautogui.press('shift')

        elif "speak with pc" in query:
            tts = gTTS(text="This is the pc speaking", lang='en')
            tts.save("pcvoice.mp3")
            # to start the file from python
            os.system("start pcvoice.mp3")

            syst = platform.system()

        elif "my system details" in query or "system details" in query or "windows details" in query:
            my_system = platform.uname()

            speak(f"System: {my_system.system}")
            speak(f"Node Name: {my_system.node}")
            speak(f"Release: {my_system.release}")
            speak(f"Version: {my_system.version}")
            speak(f"Machine: {my_system.machine}")
            speak(f"Processor: {my_system.processor}")

            print(f"System: {my_system.system}")
            print(f"Node Name: {my_system.node}")
            print(f"Release: {my_system.release}")
            print(f"Version: {my_system.version}")
            print(f"Machine: {my_system.machine}")
            print(f"Processor: {my_system.processor}")

        elif "our storage" in query or "how much storage we have" in query or "storage details" in query:
            speak(f"Memory :{psutil.virtual_memory()}")
            print(f"Memory :{psutil.virtual_memory()}")

        elif "translate to malayalam" in query or "translate in malayalam" in query or "translate into malayalam" in query:
            # speak("what you want to translate")
            # search = takecommond().lower()
            # url = f"https://www.google.com/search?q={search}"
            # # Send an HTTP GET request to the URL
            # response = requests.get(url)
            # soup = BeautifulSoup(response.content, 'html.parser')
            # # Find the specific element you want to extract
            # specific_element = soup.find('div', {'class': 'specific-class'})
            #
            # # Extract the content of the specific element
            # element_content = specific_element.get_text()
            #
            # # Print the extracted content
            # print(element_content)


            # url = 'https://translate.google.com/'
            # source_lang = 'en'
            # target_lang = 'ml'
            #
            # # Set the text you want to translate
            # text_to_translate = "hello world" """takecommond().lower()"""
            # response = requests.get(url, params={
            #     'hl': 'en',
            #     'sl': source_lang,
            #     'tl': target_lang,
            #     'text': text_to_translate
            # })
            # soup = BeautifulSoup(response.content, 'html.parser')
            #
            # # Print the HTML content of the response
            # print(soup)
            #
            # # Find the specific element that contains the translated text
            # specific_element = soup.find('div', {'class': 'result-shield-container'})
            #
            # # Print the specific element
            # print(specific_element)
            #
            # # Extract the translated text from the specific element
            # translated_text = specific_element.text.strip()
            #
            # # Print the extracted translated text
            # print(translated_text)
            # speak(translated_text)

            # Create a translator object
            translator = Translator()

            # Text to translate
            text_to_translate = "Hello, how are you?"

            # Detect the language of the text
            detected_language = translator.detect(text_to_translate).lang

            # Translate the text to another language
            translated_text = translator.translate(text_to_translate, dest='es').text

            # Print the results
            print(f"Detected language: {detected_language}")
            print(f"Translated text: {translated_text}")